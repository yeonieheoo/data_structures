#include<iostream>
#include<string>
#include<sstream>
#include<iomanip>
#include<exception>
#include<vector>
#include<list>
#include<stack>
#include<queue>
#include<ctime>
#include<fstream>
#include"inodes.h"

using namespace std;

class Tree{
	private:
		Inode* current_node; //to keep track of where we are currently at in the tree
		Inode* root; // root fo the tree
		queue<Inode*> bin; // bin for trash (discussed later in the code)
        vector<Inode*> file_found; // for functions that search specific files/folders
        Inode* previous_dir; //used to implement cd to previous directory
        
	public: //list of functions for the file system (tree)
		Tree();
		~Tree();
		// void loadData(string path);
        // void saveData(Inode* current_node, ofstream &newFile);
		void help();
		void pwd();
		void realpath(string filename);
        void realpath_store(Inode* node);
		void ls();
		void mkdir(string foldername);
		void touch(string filename, int size);
		void cd(string foldername);
		void cd_current_inode_to_parent_folder();
		void cd_current_to_prev_dir();
        void cd_current_to_root();
        void cd_path(string path);
		void find(string name);
		void mv(string foldername, string filename);
        void mv_path(string file_path, string folder_path);
		void rm(string name);
        void rm_path(string path);
        void rm_path_helper(string name);
		void size(string name);
        void size_path(string path);
        int size_return(string name);
        void size_update(string name);
		void emptybin();
		void showbin();
		void recover();
		int exit();
        void searchTree(string name, Inode* node);
        void update(Inode* node);
};