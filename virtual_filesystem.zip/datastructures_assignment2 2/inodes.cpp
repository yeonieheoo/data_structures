#include "inodes.h"

Inode::Inode(string name, int size, bool type){ //constructor that initializes the local variables
	this->type = type;
	this->name = name;
	this->parent = nullptr;
    this->size = size;
    this->decendent_size = 0;
    time_t current_time = time(0);
    tm *time_local = localtime(&current_time);
    
    // to store the date when the file/folder has been created
    int month = 1+time_local->tm_mon;
    int day = time_local->tm_mday;
    int year = 1900+time_local->tm_year-2000;
    date = to_string(month)+"-"+to_string(day)+"-"+to_string(year);
}
