#include<iostream>
#include<string>
#include<sstream>
#include<iomanip>
#include<exception>
#include<vector>
#include<list>
#include<stack>
#include<queue>
#include<ctime>
#include<fstream>

using namespace std;

class Inode // inode for each folder and files to be added to the filesystem
{
	public:
		Inode* parent; // stores information of parent
		vector<Inode*> children; // vector list of children if it is a folder
		string name; // file/folder name
		int size; // size of file/folder
		string date; // date
        string path; // path of file/folder. will be used in bin.
		bool type; // true = folder, false = file
        int decendent_size; //size of the decendents if it is a file.

		Inode(string name, int size, bool type); // constructor that initializes the local variables
};