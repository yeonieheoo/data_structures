#include "tree.h"

using namespace std;

// the main file that will be executed.
// this file should be compiled as c++14, as it utilizes a for loop that is available with c++14.
int main(){
    Tree tree;
    cout<<"Welcome to the Virtual Filesystem! "<<endl;
    cout<<"Enter a command you operate your desired method! "<<endl;
    tree.help(); // printing out all the available functions for the virtual file system
    string input;
    string command;
    string parameter;
    string parameter2;

    do{
        cout<<">";
        getline(cin,input); // reading the terminal input
        vector<string> terminal_input;
        stringstream line(input);
        string tmp;

        

        while(getline(line, tmp, ' ')) // seaparating the input to specific tokens
            terminal_input.push_back(tmp);
        
        int input_size = terminal_input.size();
        
        if(input_size==1) // command with no parameter
            command = terminal_input.at(0); 
        else if(input_size==2){ // command with one parameter
            command = terminal_input.at(0); 
            parameter=terminal_input.at(1);
        }
        else if(input_size==3){ // command with two parameters
            command=terminal_input.at(0);
            parameter=terminal_input.at(1);
            parameter2=terminal_input.at(2);
        }
        
        // checking the command and the parameters, and executing the desired function based on it.
        if(command=="pwd")
            tree.pwd();
        else if(command=="realpath")
            tree.realpath(parameter);
        else if(command=="ls")
            tree.ls();
        else if(command=="mkdir")
            tree.mkdir(parameter);
        else if(command=="touch"){
            if (parameter2=="")
                cout<<"Error: there is no size!"<<endl;
            else
                tree.touch(parameter,stoi(parameter2));
        }
        else if(command=="cd")
        {
            if (parameter=="..")
                tree.cd_current_inode_to_parent_folder();
            else if (parameter=="-")
                tree.cd_current_to_prev_dir();
            else if (parameter=="")
                tree.cd_current_to_root();
            else if (parameter[0]=='/')
                tree.cd_path(parameter);
            else if(parameter.length()>0)
                tree.cd(parameter);
            else
                tree.cd_current_to_root();
        }
            
        else if(command=="find")
            tree.find(parameter);
        else if(command=="mv"){
            if(parameter[0]=='/' && parameter2[0]=='/')
                tree.mv_path(parameter, parameter2);
            else
                tree.mv(parameter,parameter2);
        }
        else if(command=="rm"){
            if(parameter[0]=='/')
                tree.rm_path(parameter);
            else
                tree.rm(parameter);
        }
        else if(command=="size"){
            if (parameter[0]=='/')
                tree.size_path(parameter);
            else
                tree.size(parameter);
        }
        else if(command=="emptybin")
            tree.emptybin();
        else if(command=="showbin")
            tree.showbin();

        else if(command == "help")
            tree.help();
        else if(command == "exit")
            break;
        else
            cout<<"Enter a valid operation!"<<endl;

    }while(command!="exit"); // continuing the execution until the user types "exit"
    return 0;
}

