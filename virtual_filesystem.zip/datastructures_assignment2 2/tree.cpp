using namespace std;
#include "tree.h"
const int MAXBIN = 10;

Tree::Tree(){ //tree constructor
	this->root = new Inode("", 0, true); // creating root with no name and size 0
    this->current_node = this->root;
}
//==========================
Tree::~Tree(){ //tree deconstructor
    this->root = NULL;
    this->current_node = NULL;
    
    for(int i=0; i<bin.size(); i++)
        this->bin.pop();
}
//==========================
void Tree::help(){ //function that shows all the available fuctions in the terminal window
	cout<<"-----------------------------------------------------------------------------------"<<endl;
	cout<<"pwd                      :Print path of current directory"<<endl
		<<"realpath <filename>      :Print the absolute/full path of a given filename within the current directory"<<endl
		<<"ls                       :Print the children of current folder"<<endl
		<<"lssort                   :Print the children of current folder in a descending order"<<endl
		<<"mkdir <foldername>       :Create a folder under the current folder"<<endl
		<<"touch <filename size>    :Create a file under the current location with specified filename, size, and current datetime"<<endl
		<<"cd <foldername>          :Change current location to the specified folder"<<endl
		<<"cd <filename>            :Change current location to the specified file"<<endl
		<<"cd ..                    :Change current location to its parent folder"<<endl
		<<"cd -                     :Change current location to the previous working directory"<<endl
		<<"cd                       :Change current location to the root of the filesystem"<<endl
		<<"cd </my/path/name>       :Change current location to the specified path if it exists"<<endl
		<<"find <foldername>        :Return path of folder"<<endl
		<<"find <filename>          :Return path of file if it exists"<<endl
		<<"mv <filename foldername> :Move a file located in the current location to the specified folder path"<<endl
        <<"mv </my/path/filename /my/path/foldername> :Move a file to the designated folder according to the specified path given"<<endl
		<<"rm <foldername>          :Remove the specified folder and put it in the bin"<<endl
		<<"rm <filename>            :Remove the specified file and put it in the bin"<<endl
		<<"size <foldername>        :Return the total size of the folder"<<endl
		<<"size <filename>          :Return the size of the file"<<endl
		<<"emptybin                 :Empty the bin"<<endl
		<<"showbin                  :Show oldest file or folder in the bin"<<endl
        <<"exit                     :Exit the program"<<endl;
	cout<<"-----------------------------------------------------------------------------------"<<endl;
}
//==========================
void Tree::pwd(){ // function that prints the path of the current node

	stack<string> stack; // stack to keep track of inner/outer file/folder names
    Inode* curr = this->current_node;
    
    if(this->current_node->name == "")
        cout<<"/"; // if the current node is the root, it will print /, which is the path to the root
    
	while(curr!=nullptr){ // traversing the tree to the root
		stack.push(curr->name); // adding the current file/folder name to the stack
		curr = curr->parent; // update the curr inode to continue the loop
	}
    
	while(stack.empty()!=true){ // this loop will print the path
        if(stack.top()!="") // if stack is not empty
            cout<<"/";
		cout<<stack.top(); // print the file/folder name one by one from the top
		stack.pop(); // as the element has been printed, delete each
	}
    cout<<endl;
}
//==========================
void Tree::realpath(string name){ //function that prints the path of the searched node.
    searchTree(name, this->root);
    
	if(file_found.size()!=0){ // if the file we look for is not empty
        stack<string> stack;
        
        while(file_found.at(0)!=nullptr){
            stack.push(file_found.at(0)->name); // add each element to the stack
            file_found.at(0) = file_found.at(0)->parent; // update the file_found to continue the loop
        }
        while(stack.empty()!=true){
            if(stack.top()!="")
                cout<<"/";
            cout<<stack.top(); // print the element one by one from the top
            stack.pop(); // as the element has been printed, delete each
        }
        file_found.clear(); // clear the file
	}
	else
		cout<<"File does not exist";
}
//==========================
void Tree::realpath_store(Inode* node){ // function that stores the path of the node when it is deleted, so showbin will also give the path to where the deleted element was located previously
    searchTree(node->name, this->root); // searching the tree
    Inode* file = file_found.at(0); // the found folder/file
    string path_file = ""; 
    
    //this is basically the same as the pwd function logic. instead of cout, it will store in a string.
    if(file_found.size()!=0){ // if the file we look for is not empty
        stack<string> stack;
        
        while(file!=nullptr){
            stack.push(file->name); // add each element to the stack
            file = file->parent; // update the file_found to continue the loop
        }
        while(stack.empty()!=true){
            if(stack.top()!="")
                path_file+="/";
            path_file+=stack.top(); // print the element one by one from the top
            stack.pop(); // as the element has been printed, delete each
        }
        node->path = path_file;
        file_found.clear(); // clear the file_found so searchTree can be used for later functions
    }
}
//==========================
void Tree::ls(){ // function that shows the contents of the current directory
	if(this->current_node->type == true){ // if the current_node is a folder
		for(auto & element : this->current_node->children){ // for loop for all children in the current node. This is a c++14 impplementation, so need to compile with c++14.
			if(element->type == true){ // if the child is a folder
				cout<<"dir "<<element->name<<" "<<element->date<<" "<<size_return(element->name)<<" bytes"<<endl; // print the details
			}
            else{ // if the child is a file
				cout<<"file "<<element->name<<" "<<element->date<<" "<<size_return(element->name)<<" bytes"<<endl; // print the details
            }
        }
    }
    else // current_node is a file
		cout<<"This is not a folder";
}
//==========================
// void Tree::lssort(){ // make another array for the function as this can distrot the children vector in whole
// 	vector<Inode*> sort_array;
// 	if(this->current_node->type == true){
// 		for(auto & element : this->current_node->children){ // for loop for all children in the current node
// 			name = element->name;
// 			date = element->date;
// 			size = size_return(element->name);

// 			const char *each_data = "dir "name" "size" bytes"; // make a long data into a const char
// 			sort_array.append(each_data); // append the data into a newly created array
// 		}

// 		vector<Inode*> sort_array2;
// 		for(int i=0; i < this->current_node->children.size(); i++){ // swap when the left is bigger than the right 
// 			if (this->sort_array(i)->size > this->sort_array(i+1)->size){ 
// 				const char tmp = sort_array(i); 
// 				sort_array(i) = sort_array(i+1);
// 				sort_array(i+1) = tmp;
// 				delete tmp;
// 			}
// 			else 
// 				return;
// 		}

// 		for(int i=0; i < this->current_node->chilren.size(); i++){
// 			cout<<"dir "<<element->name<<" "<<element->date<<" "<<size_return(element->name)<<" bytes"<<endl; // print the details
// 		}
// 	}
// }
//=========================
void Tree::mkdir(string foldername){ // making a directory (folder)
	Inode* folder = new Inode(foldername, 10, true); // make a new inode for a folder
	folder->parent = this->current_node; // folder is located under the current_node
	this->current_node->children.push_back(folder); // add the new inode as a children of the current_node
    update(this->current_node); // updating the size of the current directory (as a new folder has been added)
}
//=========================
void Tree::touch(string filename, int size){ // making a file
	Inode* file = new Inode(filename, size, false); // make a new inode for a file
    if(this->current_node == nullptr){
        this->current_node = file;
    }
    else{
        this->current_node->children.push_back(file); // add the new inode as a children of the current_node
        this->current_node->children.back()->parent = this->current_node;
        update(this->current_node); // updadting the size of the current directory (as a new file has been added)
    }
}
//=========================
void Tree::searchTree(string name, Inode* node){ // searching the tree with the file/folder name
    if(node->type==true && node->children.empty()!=true){ // check if the node is a folder and has children
        for(auto & element : node->children){ // for loop for all children
            if(element->name == name){ // if a child's name is the same as what we are looking for
                Inode* curr = element;
                file_found.push_back(curr); // save the element in the file_found vector, which is a public attribute of the tree, so it can be accessed in other functions.
            }
            else // if the name we are looking for does not exist
                searchTree(name,element); // recursive approach that searches one level deeper in the tree. The base case will be when the file is found.
        }
    }
}
//=========================
void Tree::find(string name){ // fuction that prints the path of the found file/folder.
    searchTree(name, this->root); // check if the specific folder/file exists
    if(file_found.size()!=0){ // if what we found is not empty
        realpath(file_found.at(0)->name); // print the path
        cout<<endl;
    }
    else{ // if what we found is empty
        cout<<"The folder/file does not exist"<<endl;
        file_found.clear();
    }
}
//=========================
void Tree::cd(string name){  // function that chnages the current working directory to the desired directory
    this->previous_dir = this->current_node; // storing the directory to previous for cd_current_to_prev_dir() function.
    searchTree(name, this->root); // check if the specific folder/file exists
    
    if(file_found.size()!=0 && file_found.at(0)->type == true){ // if the searched inode is a folder
        this->current_node = file_found.at(0); // change the current_node to specific
        file_found.clear();
    }
    else if(file_found.size()!=0 && file_found.at(0)->type == false){
        cout<<"It is not a folder"<<endl;
        file_found.clear();
    }
    else
        cout<<"The folder does not exist"<<endl;
}
//=========================
void Tree::cd_current_inode_to_parent_folder(){ // function that changes the current working directory to its parent
    this->previous_dir = this->current_node; // storing the directory to previous for cd_current_to_prev_dir() function.
	if (this->current_node->parent != nullptr) // if the current_node is not a child of the root folder.
		this->current_node = this->current_node->parent; // change the current_node to its parent
	else
		cout<<"The current inode is the root"<<endl;
}
//=========================
 void Tree::cd_current_to_prev_dir(){ // function that changes the current working directory to the previous working directory
     Inode* tmp = this->current_node;
     this->current_node = this->previous_dir; // change the current_node to the previous
     this->previous_dir = this->current_node; // assign the previous directory to be the current one
 }
//=========================
void Tree::cd_current_to_root(){ // function that chnages the current working directory to the root
    this->previous_dir = this->current_node;
	this->current_node = this->root; // assign the current node to be the root
}
//=========================
 void Tree::cd_path(string path){ // function that changes the current directory to the given path
     this->previous_dir = this->current_node;
     if(path == "/"){
         this->current_node = this->root;
     }
     else{ // basically extracting the file name from the input string
         int loc = path.length()-1;
         string file_name = "";
         string file_name2 = "";
         while(path[loc]!='/'){
             file_name += path[loc];
             loc--;
         }
         
         for(int i=file_name.length()-1; i>=0; i--)
             file_name2 += file_name[i];
         
         searchTree(file_name2, this->root);
         string found_path="";
         if(file_found.size()!=0){
             stack<string> stack;
             Inode* curr = file_found.at(0);
             
             if(curr->name == "")
                 found_path+="/";
             
             while(curr!=nullptr){ // store the path/element one by one
                 stack.push(curr->name);
                 curr = curr->parent;
             }
             
             while(stack.empty()!=true){ // if all path/element has been stored, update found_path
                 if(stack.top()!="")
                     found_path+="/";
                 found_path+=stack.top();
                 stack.pop(); // delete stack element as update found_path
             }
         }
         
         if(path == found_path){ // if the found file's path is the same as the given input path
             this->current_node = file_found.at(0); // change the working directory to the found folder.
             file_found.clear();
         }
         else{
             cout<<"Incorrect path"<<endl;
             file_found.clear();
         }
     }
 }
//=========================
void Tree::mv(string filename, string foldername){  // moving the file to the desired folder
    searchTree(filename, this->root); // searching for the file
    searchTree(foldername, this->root); // searching for the folder
    if (file_found.size()==2){ // if both file and folder exists in the tree
        Inode* source_file = file_found.at(0); // make inodes for the two elements found
        Inode* dest_folder = file_found.at(1);
        dest_folder->children.push_back(source_file); //pushing the file to the desired folder
        rm_path_helper(source_file->name); // removing the file from the previous folder
        update(dest_folder); // update the size of the folder that the file is moved to 
        update(source_file->parent); // update the size of the folder that the file is deleted from
        file_found.clear();
    }
    else{
		cout<<"The specified file and folder are not in the current inode: cannot access"<<endl;
        file_found.clear();
    }
}
//=========================
void Tree::mv_path(string file_path, string folder_path){// moving the desired file to desired folder by the path. 
    Inode* source_file; // two inputs to two inodes
    Inode* dest_folder;
    bool push = true;

    if(folder_path == "/"){ // same logic as cd_path() to extract the filename and foldername from the input strings
        this->current_node = this->root;
    }
    else{
        int loc = folder_path.length()-1;
        string folder_name = "";
        string folder_name2 = "";
        while(folder_path[loc]!='/'){
            folder_name += folder_path[loc];
            loc--;
        }
        
        for(int i=folder_name.length()-1; i>=0; i--)
            folder_name2 += folder_name[i];
        
        searchTree(folder_name2, this->root);
        string folder_found_path="";
        if(file_found.size()!=0){ // if the found file is not NULL, create stack to keep track
            stack<string> stack;
            Inode* curr = file_found.at(0);
            
            if(curr->name == "")
                folder_found_path+="/";
            
            while(curr!=nullptr){
                stack.push(curr->name); // update stack
                curr = curr->parent;
            }
            
            while(stack.empty()!=true){
                if(stack.top()!="")
                    folder_found_path+="/";
                folder_found_path+=stack.top(); // after push is done above, update found folder's path
                stack.pop();
            }
        }
        
        if(folder_path == folder_found_path){
            dest_folder = file_found.at(0);
            file_found.clear();
        }
        else{
            cout<<"Incorrect folder path"<<endl;
            push=false;
            
        }
    }
    
    if(file_path == "/"){ // this is for the folder
        this->current_node = this->root;
    }
    else{
        int loc2 = file_path.length()-1;
        string file_name = "";
        string file_name2 = "";
        while(file_path[loc2]!='/'){
            file_name += file_path[loc2];
            loc2--;
        }
        
        for(int i=file_name.length()-1; i>=0; i--)
            file_name2 += file_name[i];
        
        searchTree(file_name2, this->root);
        string file_found_path="";
        if(file_found.size()!=0){
            stack<string> stack2;
            Inode* curr2 = file_found.at(0);
            
            if(curr2->name == "")
                file_found_path+="/";
            
            while(curr2!=nullptr){
                stack2.push(curr2->name);
                curr2 = curr2->parent;
            }
            
            while(stack2.empty()!=true){
                if(stack2.top()!="")
                    file_found_path+="/";
                file_found_path+=stack2.top();
                stack2.pop();
            }
        }
        
        if(file_path == file_found_path){
            source_file = file_found.at(0);
            file_found.clear();
        }
        else{
            cout<<"Incorrect file path"<<endl;
            push = false;
        }
    }
    if(push){ // if the folder and the file both exist
        dest_folder->children.push_back(source_file); // pushing back the file to the new folder
        rm_path_helper(source_file->name); // removing the file from the previous location
        update(dest_folder); // updating the size of the folder that the file moved to
        update(source_file->parent); // updtaing the size of the folder that the file was deleted from
    }
}
//=========================
void Tree::rm(string name){ // removing file from the current working directory
    searchTree(name, this->root); // searching for the desired file to delete from
    Inode* file = file_found.at(0);
    
	if (file_found.size()!=0 && file_found.at(0)->parent->name == this->current_node->name){ //if the file we are trying to remove is under the current working directory and exists.
        if (bin.size()<MAXBIN){ // if the bin is not full
			this->bin.push(file); // add specified at the back of the bin
			cout<<file->name<<" has been removed successfully"<<endl;
            file_found.clear();
            realpath_store(file);
            this->current_node->children.erase(remove(this->current_node->children.begin(), this->current_node->children.end(), file), this->current_node->children.end()); //erasing the file from the current working directory
        }
        else{
            this->bin.pop(); // if the bin is full, remove the oldest one
            this->bin.push(file); // add the specified into the bin
            cout<<file->name<<" has been removed successfully"<<endl;
            file_found.clear();
            realpath_store(file);
            this->current_node->children.erase(remove(this->current_node->children.begin(), this->current_node->children.end(), file_found.at(0)), this->current_node->children.end()); //erasing the file from the current working directory
        }
        update(file->parent); // updating the folder size the file is deleted from.
	}
	else // if the specified is not found in the current working directory
		cout<<"The specified file or folder is not in the current inode: cannot access"<<endl;
}
//=========================
void Tree::rm_path_helper(string name){// helper function for rm_path(). basically the same as rm()
    searchTree(name, this->root);
    Inode* file = file_found.at(0);
    file_found.clear();
    
    if (bin.size()<MAXBIN){ // if the bin is not full
        this->bin.push(file); // add specified at the back of the bin
        realpath_store(file);
        file->parent->children.erase(remove(file->parent->children.begin(), file->parent->children.end(), file), file->parent->children.end());
    }
    else{
        this->bin.pop(); // if the bin is full, remove the oldest one
        this->bin.push(file); // add the specified into the bin
        realpath_store(file);
        file->parent->children.erase(remove(file->parent->children.begin(), file->parent->children.end(), file), file->parent->children.end());
    }
}
//=========================
void Tree::rm_path(string path){ // function that removes a file based on the input path
    if(path == "/"){ // same logic as cd_path
        this->current_node = this->root;
    }
    else{
        int loc = path.length()-1;
        string file_name = "";
        string file_name2 = "";
        while(path[loc]!='/'){
            file_name += path[loc];
            loc--;
        }
        
        for(int i=file_name.length()-1; i>=0; i--)
            file_name2 += file_name[i];
        
        searchTree(file_name2, this->root);
        Inode* inode_found_file = file_found.at(0);
        string found_path="";
        
        if(file_found.size()!=0){
            stack<string> stack;
            Inode* curr = file_found.at(0);
            
            if(curr->name == "")
                found_path+="/";
            
            while(curr!=nullptr){
                stack.push(curr->name);
                curr = curr->parent;
            }
            
            while(stack.empty()!=true){
                if(stack.top()!="")
                    found_path+="/";
                found_path+=stack.top();
                stack.pop();
            }
        }
        
        if(path == found_path){ 
            file_found.clear();
            rm_path_helper(inode_found_file->name); // removing the found file from the folder it is in.
            update(inode_found_file); // updating the size of the folder.
        }
        else{
            cout<<"Incorrect path"<<endl;
            file_found.clear();
        }
    }
}
//=========================
void Tree::size(string name){ // function that prints the size of the file/folder
    int size = size_return(name);
    if(size!=0)
        cout<<size<<" bytes"<<endl;
    else
        cout<<"The specified file or folder does not exist"<<endl;
}
//=========================
void Tree::size_path(string path){ // function that prints the size of the file/folder based on input path
    int size;
    if(path == "/"){ // same logic as cd_path
        size = size_return(this->root->name);
        cout<<size<<" bytes"<<endl;
    }
    else{
        int loc = path.length()-1;
        string file_name = "";
        string file_name2 = "";
        while(path[loc]!='/'){
            file_name += path[loc];
            loc--;
        }
        
        for(int i=file_name.length()-1; i>=0; i--)
            file_name2 += file_name[i];
        
        searchTree(file_name2, this->root);
        string found_path="";
        if(file_found.size()!=0){
            stack<string> stack;
            Inode* curr = file_found.at(0);
            
            if(curr->name == "")
                found_path+="/";
            
            while(curr!=nullptr){
                stack.push(curr->name);
                curr = curr->parent;
            }
            
            while(stack.empty()!=true){
                if(stack.top()!="")
                    found_path+="/";
                found_path+=stack.top();
                stack.pop();
            }
        }
        
        if(path == found_path){
            size = size_return(file_found.at(0)->name); // if the file/folder is found, return the size of the file/folder
            file_found.clear();
            cout<<size<<" bytes"<<endl;
        }
        else{
            cout<<"Incorrect path"<<endl;
            file_found.clear();
        }
    }
}
//=========================
int Tree::size_return(string name){ // function that returns the size of a file/folder. used in size and size_path
    searchTree(name, this->root);
    if (file_found.size()!=0){
        int size = file_found.at(0)->size;
        int size2 = file_found.at(0)->decendent_size;
        file_found.clear();
        return size+size2;
    }
    else{
        file_found.clear();
        return 0;
    }
}
//=========================
void Tree::size_update(string name){ // updating the size of folder by adding up all the decendent's size.
    searchTree(name, this->root);
    if (file_found.size()!=0){
        if (file_found.at(0)->type == true){ // if a folder
            int total_size=0;
            for (auto & element : file_found.at(0)->children){ 
                total_size += element->size; // increase the total_size by looping through all the children
                total_size += element->decendent_size;
            }
            file_found.at(0)->decendent_size = total_size;
            file_found.clear();
        }
    }
    else
        file_found.clear();
}
//=========================
void Tree::emptybin(){ // function that empties the bin
    if(bin.size()==0) // if there is no element in the bin
        cout<<"The bin is empty: cannot show bin"<<endl;
    else{
        for (int i=0; i<bin.size(); i++) // delete elements one by one
            bin.pop();
    }
}
//=========================
void Tree::showbin(){ // function that shows the top of the bin and the information about the bin's top element
	if (bin.size() == 0)
		cout<<"The bin is empty: cannot show bin"<<endl;
	else{
		Inode* old = bin.front();
		cout<<"Next element to remove: "<<old->path<<endl<<" ("<<old->size<<", "<<old->date<<")"<<endl; //printing out the necessary information of the top element in the bin.
    }
}
//=========================
void Tree::update(Inode* node){ // function that updates the size of the given node.
    while(node->parent != nullptr){
        size_update(node->name); // update the size of the folder
        node = node->parent;
    }
}
//=========================
int Tree::exit(){
	return 0;
}
//=========================